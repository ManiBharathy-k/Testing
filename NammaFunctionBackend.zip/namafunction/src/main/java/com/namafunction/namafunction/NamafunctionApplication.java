package com.namafunction.namafunction;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NamafunctionApplication {

	public static void main(String[] args) {
		SpringApplication.run(NamafunctionApplication.class, args);
	}

}
