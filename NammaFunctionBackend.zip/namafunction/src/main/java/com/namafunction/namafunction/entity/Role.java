package com.namafunction.namafunction.entity;

public enum Role {
ADMIN,USER
}
