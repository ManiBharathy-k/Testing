package com.namafunction.namafunction.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.namafunction.namafunction.entity.Location;

public interface LocationRepository extends JpaRepository<Location, Long> {

}
