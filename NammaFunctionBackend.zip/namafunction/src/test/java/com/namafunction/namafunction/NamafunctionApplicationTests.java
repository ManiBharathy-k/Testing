package com.namafunction.namafunction;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NamafunctionApplicationTests {

	@Test
	void contextLoads() {
	}

}
